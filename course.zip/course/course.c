/**
 * @file course.c
 * @author Tahir Asif
 * @brief contains the function bodies for all functions declared in "course.h" (functions to do with the course struct defined in "course.h")
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
 
/**
 * @brief add a student to the list of students in a course
 * 
 * @param course what course to add the student to
 * @param student what student to add to the course
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // if there are no students (1 because previous line incremented the number), 
  // create a new array for students big enough for that one student
  if (course->total_students == 1)
  {
    course->students = calloc(1, sizeof(Student));
  }

  // if there are already studnets in the course, reallocate memory to make the array big enough for the new student
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }

  // actually add the student to the array of students, 
  // whether a new one had to be made or space needed to be made for this student
  course->students[course->total_students - 1] = *student; 
}


/**
 * @brief output all info about a course to standard output as a table
 * 
 * @param course what course to print
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}


/**
 * @brief find the student with the highest grade in a course
 * 
 * @param course course to find the highest graded student in
 * @return Student*: student with highest grade in the course
 */
Student* top_student(Course* course)
{
  // save running the function if there are no students in the course
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  // finds the highest graded student by iterating over the list of students and comparing each one to the currently highest one
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]); // current student's average
    if (student_average > max_average) 
    {
      max_average = student_average; // if the current student's average is higher than the previous highest, save it as the new highest
      student = &course->students[i]; 
    }   
  }

  return student;
}


/**
 * @brief get a list of students with passing grades in the course (passing means >= 50)
 * 
 * @param course course to find students with passing grades in
 * @param total_passing pointer to number of students who are passing the course, gets updated during the function
 * @return Student* : list of students who are passing
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // finds the number of passing students so an array of that size can be created
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  // iterates over the student list again and adds all passing ones to another array (called passing)
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}