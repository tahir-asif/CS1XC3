/**
 * @file course.h
 * @author Tahir Asif
 * @brief contains the course struct and function declarations for some functions to do with it
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * Course type gives the details of a course in school including course name, code, list of students, number of students
 */
typedef struct _course 
{
  char name[100]; /**< 100 byte string for name of course */
  char code[10]; /**< 10 byte string for course code */
  Student *students; /**< list of students in course */
  int total_students; /**< number of total students in course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


