/**
 * @file student.h
 * @author Tahir Asif
 * @brief contains the student struct and function declarations for some functions to do with it
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * student stuct defines first name, last name, student ID, list of grades, and number of courses
 */
typedef struct _student 
{ 
  char first_name[50]; /**< 50 byte string */
  char last_name[50]; /**< 50 byte string */
  char id[11]; /**< 11 digit id stored as 11 byte long string */
  double *grades; /**< list of grades stored with high decimal precision */
  int num_grades; /**< number of courses (i.e grades) the student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
