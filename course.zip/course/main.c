/**
 * @file main.c
 * @author Tahir Asif
 * @brief The main file
 * @version 0.1
 * @date 2022-04-11
 * 
 * @mainpage Course Related Functions
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief main function. creates a course called "MATH101" and defines all it's attributes, generates 20 random students, then prints the course info, as well as the student with the highest grade and which students are passing the course.
 * 
 * @return int 
 */
int main()
{
  // seeds the random number generator using the time
  srand((unsigned) time(NULL));

  // defines the course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // generates 20 random students, each with 8 grades
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  // prints out the course info, the student with the highest grade, then the number and info of passing students
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}