/**
 * @file student.c
 * @author Tahir Asif
 * @brief contains the function bodies for all functions declared in "student.h" (functions to do with the student struct defined in "student.h")
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"


/**
 * @brief add a grade to a students record
 * 
 * @param student student to add grade to
 * @param grade grade to add to student
 * 
 * @return nothing, changes student attributes in place 
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++; // adds 1 to the number of grades the student has

  // creates an array for the students grades if this is their first grade
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));

  // if not then then adds space to the current array for this new grade
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }

  // actually assigns the grade
  student->grades[student->num_grades - 1] = grade;
}


/**
 * @brief averages all of a students grades
 * 
 * @param student student to average grades of
 * @return double: value of grade as a double
 */
double average(Student* student)
{
  // average of 0 if student has no grades
  if (student->num_grades == 0) return 0;

  // if they have some grades, then iterates over them, totals them, divdes total by number of grades
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}


/**
 * @brief outputs all attributes of a student to standard output
 * 
 * @param student student to have information printed of
 * 
 * @return nothing, prints student attributes
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}


/**
 * @brief creates a new student struct with randomly assignmed values
 * 
 * @param grades how many grades the new student should have
 * @return Student*: pointer to the new student
 */
Student* generate_random_student(int grades)
{
  // all possible names to be randomly chosen from
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  // create a new student struct
  Student *new_student = calloc(1, sizeof(Student));

  // assign a random name to the new student
  strcpy(new_student->first_name, first_names[rand() % 24]); // the random number mod 24 gives a number from [0,23] corresponding to the array index
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // assigns a random student ID by picking a random digit [0,9] and adding 48 to it for each place of the ID to correspond to ASCII values for 0-9
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // generates random grades for the student over the interval [25, 99]
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}